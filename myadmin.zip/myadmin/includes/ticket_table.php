<div class="container">

<br /><br />  
  <table class="table table-bordered table-hover mytable text-center">
    <thead>
      <tr style="background-color:;color:white;">
	    <th style="text-align:center;">ID</th>
        <th style="text-align:center;">Title</th>
        <th style="text-align:center;">Creator</th>
        <th style="text-align:center;">Create_Date</th>
		<th style="text-align:center;">Supplier name</th>
		<th style="text-align:center;">comments</th>
		<th style="text-align:center;">Status</th>
      </tr>
    </thead>
    <tbody>
      <tr>
	    <td>1</td>
        <td>Power supply problem</td>
        <td>Mahmoud</td>
        <td>4/15/2020</td>
		<td>Hend</td>
		<td>0</td>
		<td>
		 <select class="form-control" name="sticket_status">
		    <option name="open" value="open">Open</option>
			<option name="pending" value="pending">Pending</option>
			<option name="closed" value="closed">Closed</option>
			<option name="reopen" value="reopen">Re-open</option>
		 </select>
		</td>
      </tr>
    </tbody>
  </table>
</div>