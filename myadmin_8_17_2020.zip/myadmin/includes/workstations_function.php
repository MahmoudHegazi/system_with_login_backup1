
<?php 

function getdevices() {
global $con;
$query = "SELECT * FROM workstation";
$result = mysqli_query($con, $query);
$devices_count = mysqli_num_rows($result);
if(mysqli_num_rows($result) < 1) {
	// No rows found 
    echo "<div class='alert alert-info'>
           <strong>Info!</strong> No Device Found.
       </div>";
	   return;
} 
	// we found the rows
		 echo "<br /><div class='alert alert-success'>
           <strong>Found: </strong>" . $devices_count ." Devices</div>";

?>

    <thead>
      <tr>
        <th>ID</th>
        <th>Service Tag</th>
        <th>purchased</th>
        <th>Supplier</th>
	<th>Price</th>
	<th>Actions</th>
      </tr>
    </thead>
    <tbody>
	
<?php 	 

     while ($row = mysqli_fetch_assoc($result)) {
	         $device_id = $row['id'];
		 $device_tag = $row['service_tag'];
                 $device_man = $row['manufacture'];
		 $device_purchased = $row['purchased_date'];
		 $device_supplier_id = $row['supplier_id'];
		 $device_price = $row['price'];
		 $device_history = $row['history'];
		 $device_status = $row['status'];
		 $device_images = $row['images'];
		 $device_model = $row['model'];
		 $device_type = $row['type'];     
?>	

      <tr>
        <td><?php echo $device_id; ?></td>
        <td><?php echo $device_tag; ?></td>
        <td><?php echo $device_purchased; ?></td>
		<td><?php echo $device_supplier_id; ?></td>
		<td><?php echo $device_price; ?></td>
        <td><button class="btn btn-danger">Delete</button> <button class="btn btn-info">update</button></td>
      </tr>

<?php }}
	getdevices();
?>	  
    </tbody>
  </table>
  
